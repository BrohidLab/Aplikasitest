<?php
    $id_user = $this->session->userdata('id_user');
    if (empty($id_user)) {
        echo "<script>alert('Silahkan login terlebih dahulu..!')</script>";
        echo "<script>document.location='".site_url('Welcome')."'</script>";
    }
?>

<!DOCTYPE html>
<html>
<head>
    <title>Dashboard Data User</title>
    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/style.css">
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap.min.css">
</head>
<body>
    <div class="header">
        <span class="title-header">Aplikasi Test</span>
        <a href="<?php echo site_url('Welcome/logout');?>" onClick="javascript: return confirm('Apakah anda yakin ingin keluar ??')"><img src="<?php echo base_url();?>assets/assets_home/icon/logout.png" class="logout"></a>
    </div>
    <div class="content">
        <h3 class="title-content">Data User</h3>
        <hr>
        <br><br>
        <table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
            <tr>
                <th>No.</th>
                <th>Nama Lengkap</th>
                <th>Gender</th>
                <th>Email</th>
                <th>No. Telphen</th>
                <th>Pekerjaan</th>
                <th>Password</th>
                <th>Photo</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php
                $no = 0;
                foreach ($datauser as $value) {
                    $no++;
            ?>
                <tr>
                    <td><?php echo $no;?></td>
                    <td><?php echo $value->nama_lengkap;?>.</td>
                    <td><?php echo $value->gender;?></td>
                    <td><?php echo $value->email;?></td>
                    <td><?php echo $value->no_telp;?></td>
                    <td><?php echo $value->pekerjaan;?></td>
                    <td><?php echo $value->password;?></td>
                    <td><img src="<?php echo base_url();?>assets/assets_home/photouser/<?php echo $value->photo;?>" width="70px"></td>
                    <td><a href="<?php echo site_url('HomeController/hapus_data/');?><?php echo $value->id_user;?>" onClick="javascript: return confirm('Apakah anda yakin ingin menghapusnya ??')" class="btn-hapus">Hapus</a></td>
                </tr>
            <?php
                }
            ?>
            
        </tbody>
    </table>
    </div>

    <script type="text/javascript" src="https://code.jquery.com/jquery-3.3.1.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap.min.js"></script>
    <script type="text/javascript">
            $(document).ready(function() {
                $('#example').DataTable();
            } );
    </script>
</body>
</html>