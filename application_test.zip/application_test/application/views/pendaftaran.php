<!DOCTYPE html>
<html>
<head>
	<title>Form Data Login User</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/style.css">
</head>
<body>
	<div class="form-login">
		<h3 class="title">Form Pendaftaran User</h3>
		<div class="container-login">
			<div class="card">
				<?php echo form_open_multipart('Welcome/simpan_user');?>
				<label class="label">Username or Email</label>
				<input type="email" class="input" name="email" placeholder="Silahkan masukkan email anda..." required="required">
				<label class="label">Password</label>
				<input type="password" class="input" name="password" placeholder="*******" required="required">
				<label class="label">Konfirmasi Password</label>
				<input type="password" class="input" name="kon_pass" placeholder="*******" required="required">
				<label class="label">Nama Lengkap</label>
				<input type="text" class="input" name="nama_lengkap" placeholder="Silahkan masukkan nama lengkap anda..." required="required">
				<label class="label">Gender</label>
				<input type="radio" class="radio" name="gender" value="Laki-laki" placeholder="*******" required="required"> Laki-laki &nbsp;&nbsp;
				<input type="radio" class="radio" name="gender" value="Perempuan" placeholder="*******" required="required"> Perempuan<br><br>
				<label class="label">No Telphone</label>
				<input type="text" class="input" name="no_hp" placeholder="081234xxxxx" required="required">
				<label class="label">Pekerjaan</label>
				<select class="input" name="pekerjaan" required="required">
					<option value="">Pilih</option>
					<option value="Karyawan Swasta">Karyawan Swasta</option>
					<option value="Pegawai Negeri">Pegawai Negeri</option>
					<option>Belum Bekerja</option>
				</select>
				<label class="label">Photo</label>
				<input type="file" class="input" name="foto" placeholder="*******" required="required">
				<button type="submit" class="btn-success">Daftar</button>
				<label class="notifi">Sudah punya akses klik <a href="<?php echo site_url('Welcome');?>">di sini</a></label>
				<?php echo form_close();?>
			</div>
		</div>
	</div>
</body>
</html>