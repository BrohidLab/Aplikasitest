<?php
	$id_user = $this->session->userdata('id_user');
	if (!empty($id_user)) {
        echo "<script>document.location='".site_url('HomeController')."'</script>";
    }
?>
<!DOCTYPE html>
<html>
<head>
	<title>Form Data Login User</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/style.css">
</head>
<body>
	<div class="form-login">
		<br><br><br>
		<h3 class="title">Form Login User</h3>
		<div class="container-login">
			<div class="card">
				<?php echo form_open('Welcome/proses_login');?>
				<label class="label">Username Or Email</label>
				<input type="email" class="input" name="email" placeholder="Silahkan masukkan email anda..." required="required">
				<label class="label">Password</label>
				<input type="password" class="input" name="password" placeholder="*******" required="required">
				<button type="submit" class="btn-success">Masuk</button>
				<label class="notifi">Belum punya akses klik <a href="<?php echo site_url('Welcome/pendaftaran');?>">di sini</a></label>
				<?php echo form_close();?>
			</div>
		</div>
	</div>
</body>
</html>