<?php   
	defined('BASEPATH') OR exit('No direct script access allowed');

	/**
	 * 
	 */
	class ModelProses extends CI_Model
	{
		
		function __construct()
		{
			parent::__construct();
		}

		function simpan_user($data){
			return $this->db->insert('tb_user', $data);
		}

		function proses_login($data){
			$this->db->where($data);
			return $this->db->get('tb_user');
		}

		function datauser(){
			return $this->db->get('tb_user');
		}

		function hapus_user($id_user){
			$this->db->where('id_user', $id_user);
			return $this->db->delete('tb_user');
		}
	}

?>