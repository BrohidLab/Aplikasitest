<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		$this->load->view('login');
	}

	function pendaftaran(){
		$this->load->view('pendaftaran');
	}

	function simpan_user(){
		$email = $this->input->post('email');
		$password = $this->input->post('password');
		$kon_pass = $this->input->post('kon_pass');
		$nama_lengkap = $this->input->post('nama_lengkap');
		$gender = $this->input->post('gender');
		$no_hp = $this->input->post('no_hp');
		$pekerjaan = $this->input->post('pekerjaan');

		$config['upload_path'] = "./assets/assets_home/photouser";
        $config['allowed_types'] = "jpg|jpeg|png";

        $this->load->library('upload', $config);

        if (!$this->upload->do_upload("foto")) {
            echo "<script>alert('Gambar yang anda upload ada masalah')</script>";
			echo "<script>window.history.back()</script>";
        }else{
            $file = $this->upload->data();
            $data = array(
					'id_user' => null,
					'email' => $email,
					'password' => $password,
					'nama_lengkap' => $nama_lengkap,
					'gender' => $gender,
					'no_telp' => $no_hp,
					'pekerjaan' => $pekerjaan,
					'photo' => $file['file_name']
				);

			if ($password != $kon_pass) {
				echo "<script>alert('Mohon maaf password & konfirmasi password tidak sama, silahkan cek kembali...')</script>";
				echo "<script>window.history.back()</script>";
			}else{
				$proses =$this->ModelProses->simpan_user($data);
				if ($proses) {
					echo "<script>alert('Data berhasil tersimpan')</script>";
					echo "<script>document.location= '".site_url('Welcome')."'</script>";
				}else{
					echo "<script>alert('Data gagal di simpan')</script>";
					echo "<script>window.history.back()</script>";
				}
			}
        }

		
	}

	function proses_login(){
		$username = $this->input->post('email');
		$password = $this->input->post('password');
		$data = array(
					"email" => $username,
					"password" => $password
				);

		$proses = $this->ModelProses->proses_login($data);
		$dataarray = $proses->row(); 
		$jumlah = $proses->num_rows();

		if ($jumlah > 0) {

			$datasession = array(
								"nama" => $dataarray->email,
								"id_user" => $dataarray->id_user
							);
			$this->session->set_userdata($datasession);

			echo "<script>alert('Sukses, Selamat Datang Di Test Online.')</script>";
			echo "<script>document.location='".site_url('HomeController')."'</script>";
		}else{
			echo "<script>alert('Gagal, Silahkan cek kembali username & password anda..!.')</script>";
			echo "<script>document.location='".site_url('welcome')."'</script>";
		}
	}

	function logout(){
		$this->session->sess_destroy();
		redirect(site_url('Welcome'));
	}
}
