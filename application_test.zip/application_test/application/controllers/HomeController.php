<?php 
	defined('BASEPATH') OR exit('No direct script access allowed');
	
	/**
	 * 
	 */
	class HomeController extends CI_Controller
	{
		
		function __construct()
		{
			parent::__construct();
		}

		public function index(){
			$data['datauser'] = $this->ModelProses->datauser()->result();
			$this->load->view('home.php', $data);
		}


		function hapus_data($id_user){
			$proses =$this->ModelProses->hapus_user($id_user);
			if ($proses) {
				echo "<script>alert('Data berhasil terhapus')</script>";
				echo "<script>document.location= '".site_url('HomeController')."'</script>";
			}else{
				echo "<script>alert('Data gagal di terhapus')</script>";
				echo "<script>window.history.back()</script>";
			}
		}
	}

?>